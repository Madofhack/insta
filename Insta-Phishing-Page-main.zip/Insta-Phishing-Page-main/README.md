# Insta-Phishing-Page
Instagram Phishing Page 

A phishing page for instagram 
https://igphish.netlify.app/
visit there to see the website

<hr>
<h1> How to host it for phishing</h1>
<h5> Step 1- </h5> 
Dowload all files and move all files in one folder.<br>
<h5> Step 2- </h5> 
Goto https://www.netlify.com and create a new account.<br>
<h5> Step 3- </h5> 
Now deploy your website folder there.
And host it. <br>
<h5> Step 4- </h5> 
Now change the site name to like real instagram website.<br>
<h5> Step 5- </h5> 
It's done now send the link of your fake page website to victim.
when he will login you will get login details in the forms section of the Netlify website dashboard.



~MG Hacker 
